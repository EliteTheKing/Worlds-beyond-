# Worlds Beyond Multiplayer Server

A production-ready starting backend for Worlds Beyond using Node.js, Express, and Socket.IO.

## Features

- Real Socket.IO multiplayer
- Automatic server/room assignment
- Maximum 40 players per room
- Server 1 fills first, then Server 2, etc.
- Player movement/name/level/HP/appearance state synchronization
- Disconnect cleanup
- `/health` endpoint
- `PORT` environment variable support
- CORS configuration
- No browser-only/localStorage multiplayer simulation

## Run locally

```bash
npm install
npm start
```

The server listens on `PORT` or port `3000`.

Health check:

`http://localhost:3000/health`

## Connect the Worlds Beyond client

Set:

```text
VITE_MULTIPLAYER_SERVER_URL=https://YOUR-SERVER-HOST
```

The client should connect with Socket.IO to that URL.

## Important

This backend is intentionally separate from the existing Three.js world. It does not alter world coordinates, rendering, combat formulas, inventory, equipment, or the character creator.
